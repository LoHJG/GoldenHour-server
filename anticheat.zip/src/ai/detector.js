import { RotationWindow, DEFAULT_NORM } from "./features.js";
import { loadModel } from "./model.js";
import { DatasetRecorder } from "./dataset.js";

const DEFAULTS = {
  enabled: false,
  record: false,
  modelPath: "AIACModel/model.json",
  dataDir: "AIACModel/data",
  recordLabel: "unknown",
  window: 150,
  combatWindowMs: 5000,
  maxGapMs: 250,
  threshold: null,
  reportCooldownMs: 5000,
  checkBots: false,
};

const num = (v, fallback = 0) => (Number.isFinite(Number(v)) ? Number(v) : fallback);

export class AIDetector {
  constructor(options = {}, hooks = {}) {
    this.cfg = { ...DEFAULTS, ...options };
    this.windowSize = Math.max(8, Math.round(num(this.cfg.window, 150)));
    this.combatWindowMs = Math.max(500, num(this.cfg.combatWindowMs, 5000));
    this.maxGapMs = Math.max(50, num(this.cfg.maxGapMs, 250));
    this.onFlag = typeof hooks.onFlag === "function" ? hooks.onFlag : null;
    this.states = new Map();

    const loaded = loadModel(this.cfg.modelPath);
    this.model = loaded.model;
    this.modelPath = loaded.path;
    this.modelError = loaded.reason;
    if (this.model && this.model.window !== this.windowSize) {
      this.modelError = `model window ${this.model.window} != config window ${this.windowSize}`;
      this.model = null;
    }
    this.norm = this.model?.norm || DEFAULT_NORM;

    this.recorder = this.cfg.record
      ? new DatasetRecorder({
          dir: this.cfg.dataDir,
          label: this.cfg.recordLabel,
          window: this.windowSize,
        })
      : null;

    this.active = Boolean(this.model || this.recorder);
    const configuredThreshold = this.cfg.threshold;
    this.threshold = configuredThreshold === null ||
        configuredThreshold === undefined ||
        configuredThreshold === ""
      ? num(this.model?.threshold, 0.85)
      : num(configuredThreshold, num(this.model?.threshold, 0.85));

    if (!this.active && this.cfg.enabled) {
      const why = this.modelError || "model missing";
      console.warn(`[AIAC] disabled: ${why}`);
    }
  }

  get status() {
    return {
      active: this.active,
      model: Boolean(this.model),
      recording: Boolean(this.recorder),
      modelPath: this.modelPath,
      modelError: this.modelError,
      threshold: this.threshold,
      window: this.windowSize,
      dataFile: this.recorder?.file || null,
    };
  }

  skip(player) {
    if (!player) return true;
    return !!(player.bot && !this.cfg.checkBots);
  }

  stateKey(player) {
    if (player?.id !== undefined && player?.id !== null) return player.id;
    if (player?.uid !== undefined && player?.uid !== null) return `uid:${player.uid}`;
    return player;
  }

  stateFor(player) {
    const key = this.stateKey(player);
    let st = this.states.get(key);
    if (!st) {
      st = {
        win: new RotationWindow(this.windowSize, this.maxGapMs),
        lastShotAt: 0,
        lastInputAt: 0,
      };
      this.states.set(key, st);
    }
    return st;
  }

  onSpawn(player) {
    const st = this.states.get(this.stateKey(player));
    if (st) {
      st.win.reset();
      st.lastShotAt = 0;
      st.lastInputAt = 0;
    }
  }

  remove(player) {
    if (player) this.states.delete(this.stateKey(player));
  }

  onShot(player, info = {}) {
    if (!this.active || this.skip(player)) return;
    const now = num(info.now, Date.now());
    const st = this.stateFor(player);
    if (!st.lastShotAt || now - st.lastShotAt > this.combatWindowMs) st.win.reset();
    st.lastShotAt = now;
  }

  onInput(player, input, now = Date.now()) {
    if (!this.active || this.skip(player) || !input || typeof input !== "object") return;
    const st = this.stateFor(player);
    st.lastInputAt = now;

    if (!st.lastShotAt || now - st.lastShotAt > this.combatWindowMs) {
      if (st.win.length) st.win.reset();
      return;
    }

    const full = st.win.push(input.yaw, input.pitch, now);
    if (!full) return;

    let prob = null;
    if (this.model) {
      try {
        const result = this.model.predict(st.win.features(this.norm));
        prob = result.prob;
      } catch (err) {
        if (!this.modelError) this.modelError = err.message;
      }
    }

    if (this.recorder) {
      this.recorder.append({
        v: 1,
        ts: now,
        player: player.name,
        uid: player.uid,
        bot: !!player.bot,
        ai: !!player.ai,
        label: this.cfg.recordLabel,
        window: this.windowSize,
        seq: st.win.raw(),
        prob,
      });
    }

    if (prob !== null && prob >= this.threshold && this.onFlag) {
      this.onFlag(player, prob);
    }

    st.win.reset();
  }
}
