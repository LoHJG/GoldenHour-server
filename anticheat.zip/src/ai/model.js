import fs from "node:fs";
import path from "node:path";

const FORMAT = "AIACModel/v1";
const ARCH = "cnn1d";

const num = (v, fallback = 0) => (Number.isFinite(Number(v)) ? Number(v) : fallback);

function assert(cond, message) {
  if (!cond) throw new Error(message);
}

function readLayer(layer, index) {
  assert(layer && typeof layer === "object", `layer ${index} missing`);
  assert(layer.type === "conv1d", `layer ${index} type must be conv1d`);
  const inCh = Math.round(num(layer.in));
  const outCh = Math.round(num(layer.out));
  const kernel = Math.round(num(layer.kernel));
  const padding = Math.round(num(layer.padding));
  const dilation = Math.round(num(layer.dilation, 1));
  assert(inCh > 0 && outCh > 0 && kernel > 0, `layer ${index} shape invalid`);
  assert(Array.isArray(layer.weight) && layer.weight.length === outCh * inCh * kernel,
    `layer ${index} weight length mismatch`);
  assert(Array.isArray(layer.bias) && layer.bias.length === outCh,
    `layer ${index} bias length mismatch`);
  return { inCh, outCh, kernel, padding, dilation, weight: layer.weight, bias: layer.bias };
}

function conv1d(input, inCh, inLen, layer) {
  const { outCh, kernel, padding, dilation, weight, bias } = layer;
  const outLen = inLen + padding * 2 - dilation * (kernel - 1);
  assert(outLen > 0, "conv output length invalid");
  const out = new Float32Array(outCh * outLen);
  for (let oc = 0; oc < outCh; oc++) {
    const outBase = oc * outLen;
    const wBase = oc * inCh * kernel;
    for (let t = 0; t < outLen; t++) {
      let sum = num(bias[oc]);
      for (let ic = 0; ic < inCh; ic++) {
        const inBase = ic * inLen;
        const kBase = wBase + ic * kernel;
        for (let k = 0; k < kernel; k++) {
          const pos = t + k * dilation - padding;
          if (pos >= 0 && pos < inLen) {
            sum += num(weight[kBase + k]) * num(input[inBase + pos]);
          }
        }
      }
      out[outBase + t] = sum > 0 ? sum : 0;
    }
  }
  return { data: out, channels: outCh, length: outLen };
}

function pool(input, channels, length) {
  const out = new Float32Array(channels * 2);
  for (let c = 0; c < channels; c++) {
    let sum = 0;
    let max = -Infinity;
    const base = c * length;
    for (let i = 0; i < length; i++) {
      const v = num(input[base + i]);
      sum += v;
      if (v > max) max = v;
    }
    out[c] = sum / Math.max(1, length);
    out[channels + c] = max;
  }
  return out;
}

function linear(input, inSize, outSize, weight, bias, relu = false) {
  assert(Array.isArray(weight) && weight.length === outSize * inSize, "dense weight length mismatch");
  assert(Array.isArray(bias) && bias.length === outSize, "dense bias length mismatch");
  const out = new Float32Array(outSize);
  for (let o = 0; o < outSize; o++) {
    let sum = num(bias[o]);
    const base = o * inSize;
    for (let i = 0; i < inSize; i++) sum += num(weight[base + i]) * num(input[i]);
    out[o] = relu && sum < 0 ? 0 : sum;
  }
  return out;
}

function sigmoid(v) {
  if (v >= 0) return 1 / (1 + Math.exp(-v));
  const e = Math.exp(v);
  return e / (1 + e);
}

export class RotationCnnModel {
  constructor(model) {
    assert(model && typeof model === "object", "model json missing");
    assert(model.format === FORMAT, `model format must be ${FORMAT}`);
    assert(model.arch === ARCH, `model arch must be ${ARCH}`);
    this.window = Math.round(num(model.window));
    this.channels = Math.round(num(model.channels, 3));
    this.threshold = num(model.threshold, 0.85);
    this.norm = {
      mean: Array.isArray(model.norm?.mean) ? model.norm.mean.map(Number) : [0, 0, 0],
      std: Array.isArray(model.norm?.std) ? model.norm.std.map(Number) : [30, 20, 40],
    };
    assert(this.window >= 8 && this.channels === 3, "model window/channels invalid");
    assert(Array.isArray(model.layers) && model.layers.length >= 2, "model layers invalid");
    this.layers = model.layers.map(readLayer);
    assert(this.layers[0].inCh === this.channels, "first layer channels mismatch");
    for (let i = 1; i < this.layers.length; i++) {
      assert(this.layers[i].inCh === this.layers[i - 1].outCh, `layer ${i} channels mismatch`);
    }
    const head = model.head;
    const pooled = this.layers[this.layers.length - 1].outCh * 2;
    assert(head && head.in === pooled, "head input mismatch");
    assert(Array.isArray(head.weight1) && head.weight1.length === head.hidden * head.in,
      "head weight1 length mismatch");
    assert(Array.isArray(head.bias1) && head.bias1.length === head.hidden,
      "head bias1 length mismatch");
    assert(Array.isArray(head.weight2) && head.weight2.length === head.hidden,
      "head weight2 length mismatch");
    assert(Array.isArray(head.bias2) && head.bias2.length === 1, "head bias2 length mismatch");
    this.head = head;
  }

  predict(features) {
    assert(features && features.length === this.channels * this.window,
      "feature length mismatch");
    let x = { data: features, channels: this.channels, length: this.window };
    for (const layer of this.layers) {
      x = conv1d(x.data, x.channels, x.length, layer);
    }
    const pooled = pool(x.data, x.channels, x.length);
    const hidden = linear(pooled, this.head.in, this.head.hidden, this.head.weight1, this.head.bias1, true);
    const logits = linear(hidden, this.head.hidden, 1, this.head.weight2, this.head.bias2, false);
    return {
      prob: sigmoid(logits[0]),
      logits: logits[0],
    };
  }
}

export function loadModel(modelPath) {
  const resolved = path.resolve(process.cwd(), modelPath || "AIACModel/model.json");
  if (!fs.existsSync(resolved)) return { model: null, path: resolved, reason: "model file missing" };
  try {
    const json = JSON.parse(fs.readFileSync(resolved, "utf-8"));
    return { model: new RotationCnnModel(json), path: resolved, reason: null };
  } catch (err) {
    return { model: null, path: resolved, reason: err.message };
  }
}

export { FORMAT, ARCH };
