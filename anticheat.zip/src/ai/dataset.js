import fs from "node:fs";
import path from "node:path";

const clean = (v) => String(v || "unknown").toLowerCase().replace(/[^a-z0-9_-]/g, "_").slice(0, 32);

function dateStamp(now = new Date()) {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}${m}${d}`;
}

export class DatasetRecorder {
  constructor({ dir, label, window } = {}) {
    this.dir = path.resolve(process.cwd(), dir || "AIACModel/data");
    this.label = clean(label);
    this.window = window;
    this.file = path.join(this.dir, `rotations-${this.label}-${dateStamp()}.jsonl`);
    this.warned = false;
    fs.mkdirSync(this.dir, { recursive: true });
  }

  append(record) {
    if (!record) return null;
    try {
      fs.appendFileSync(this.file, `${JSON.stringify(record)}\n`, "utf-8");
      return this.file;
    } catch (err) {
      if (!this.warned) {
        this.warned = true;
        console.warn(`[AIAC] dataset write failed: ${err.message}`);
      }
      return null;
    }
  }
}
