const RAD2DEG = 180 / Math.PI;
const DEFAULT_NORM = {
  mean: [0, 0, 0],
  std: [30, 20, 40],
};

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const num = (v, fallback = 0) => (Number.isFinite(Number(v)) ? Number(v) : fallback);

export function wrapDeg(delta) {
  let d = (delta + 180) % 360;
  if (d < 0) d += 360;
  return d - 180;
}

export class RotationWindow {
  constructor(size = 150, maxGapMs = 250) {
    this.size = Math.max(2, Math.round(num(size, 150)));
    this.maxGapMs = Math.max(50, num(maxGapMs, 250));
    this.dyaw = [];
    this.dpitch = [];
    this.prev = null;
  }

  get length() {
    return this.dyaw.length;
  }

  get full() {
    return this.dyaw.length >= this.size;
  }

  reset() {
    this.dyaw.length = 0;
    this.dpitch.length = 0;
    this.prev = null;
  }

  push(yaw, pitch, now = Date.now()) {
    const y = Number(yaw);
    const p = Number(pitch);
    if (!Number.isFinite(y) || !Number.isFinite(p)) return false;

    let dyaw = 0;
    let dpitch = 0;
    if (this.prev) {
      const dt = now - this.prev.t;
      if (dt >= 0 && dt <= this.maxGapMs) {
        dyaw = wrapDeg((y - this.prev.yaw) * RAD2DEG);
        dpitch = (p - this.prev.pitch) * RAD2DEG;
      }
    }

    this.prev = { yaw: y, pitch: p, t: now };
    this.dyaw.push(dyaw);
    this.dpitch.push(dpitch);
    while (this.dyaw.length > this.size) {
      this.dyaw.shift();
      this.dpitch.shift();
    }
    return this.full;
  }

  raw() {
    return { dyaw: this.dyaw.slice(), dpitch: this.dpitch.slice() };
  }

  features(norm = DEFAULT_NORM) {
    const n = this.dyaw.length;
    const data = new Float32Array(3 * n);
    const mean = norm?.mean || DEFAULT_NORM.mean;
    const std = norm?.std || DEFAULT_NORM.std;
    for (let i = 0; i < n; i++) {
      const dy = this.dyaw[i];
      const dp = this.dpitch[i];
      const mag = Math.hypot(dy, dp);
      data[i] = clamp((dy - num(mean[0])) / Math.max(1e-3, num(std[0], 1)), -6, 6);
      data[n + i] = clamp((dp - num(mean[1])) / Math.max(1e-3, num(std[1], 1)), -6, 6);
      data[2 * n + i] = clamp((mag - num(mean[2])) / Math.max(1e-3, num(std[2], 1)), -6, 6);
    }
    return data;
  }
}

export { DEFAULT_NORM };
