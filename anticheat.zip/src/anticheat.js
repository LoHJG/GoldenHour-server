import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { AIDetector } from "./ai/detector.js";

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const ANTICHEAT_CONFIG_PATH = process.env.ANTICHEAT_CONFIG
  ? path.resolve(process.env.ANTICHEAT_CONFIG)
  : path.join(HERE, "anticheat.cfg");

const FORBIDDEN_KEYS = new Set(["__proto__", "prototype", "constructor"]);

function stripComment(line) {
  let quote = "";
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (quote) {
      if (ch === quote && line[i - 1] !== "\\") quote = "";
      continue;
    }
    if (ch === '"' || ch === "'") {
      quote = ch;
      continue;
    }
    if (ch === "#" && (i === 0 || /\s/.test(line[i - 1]))) {
      return line.slice(0, i);
    }
  }
  return line;
}

function envValue(name, fallback = "") {
  const value = process.env[name];
  return value === undefined || value === "" ? fallback : value;
}

function parseValue(raw, lineNo) {
  const value = raw.trim();
  if (value.startsWith("envbool:")) {
    return envValue(value.slice(8)).trim() === "1";
  }
  if (value.startsWith("envnum:")) {
    const text = envValue(value.slice(7)).trim();
    if (!text) return null;
    const number = Number(text);
    if (!Number.isFinite(number)) {
      throw new Error(`${ANTICHEAT_CONFIG_PATH}:${lineNo}: envnum 不是有效数字`);
    }
    return number;
  }
  if (value.startsWith("envstr:")) {
    const rest = value.slice(7);
    const sep = rest.indexOf("|");
    const name = sep < 0 ? rest : rest.slice(0, sep);
    const fallback = sep < 0 ? "" : rest.slice(sep + 1);
    return envValue(name, fallback);
  }
  if (value.startsWith("env:")) {
    return envValue(value.slice(4));
  }
  if (!value) return "";
  if (value === "true") return true;
  if (value === "false") return false;
  if (value === "null") return null;
  if (/^[\[{"]/.test(value) || /^[-+]?\d/.test(value)) {
    try {
      return JSON.parse(value);
    } catch {
      throw new Error(`${ANTICHEAT_CONFIG_PATH}:${lineNo}: 值不是有效 JSON`);
    }
  }
  return value;
}

function setValue(root, dottedKey, value, lineNo) {
  const parts = dottedKey.split(".").filter(Boolean);
  if (!parts.length) throw new Error(`${ANTICHEAT_CONFIG_PATH}:${lineNo}: 缺少配置键`);
  for (const part of parts) {
    if (FORBIDDEN_KEYS.has(part)) {
      throw new Error(`${ANTICHEAT_CONFIG_PATH}:${lineNo}: 非法配置键 ${part}`);
    }
  }
  let target = root;
  for (const part of parts.slice(0, -1)) {
    if (!target[part] || typeof target[part] !== "object" || Array.isArray(target[part])) {
      target[part] = {};
    }
    target = target[part];
  }
  target[parts[parts.length - 1]] = value;
}

function loadConfig() {
  let text;
  try {
    text = fs.readFileSync(ANTICHEAT_CONFIG_PATH, "utf8");
  } catch (error) {
    throw new Error(`[YokaiAC] 无法读取 ${ANTICHEAT_CONFIG_PATH}: ${error.message}`);
  }

  const root = {};
  let section = "";
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  for (let index = 0; index < lines.length; index++) {
    const lineNo = index + 1;
    const line = stripComment(lines[index]).trim();
    if (!line) continue;

    const sectionMatch = /^\[([A-Za-z0-9_.-]+)\]$/.exec(line);
    if (sectionMatch) {
      section = sectionMatch[1];
      continue;
    }

    const separator = line.indexOf("=");
    if (separator < 1) {
      throw new Error(`${ANTICHEAT_CONFIG_PATH}:${lineNo}: 缺少 key = value`);
    }
    const key = line.slice(0, separator).trim();
    const rawValue = line.slice(separator + 1);
    const fullKey = section ? `${section}.${key}` : key;
    setValue(root, fullKey, parseValue(rawValue, lineNo), lineNo);
  }

  if (!Object.keys(root).length) {
    throw new Error(`[YokaiAC] ${ANTICHEAT_CONFIG_PATH} 没有配置项`);
  }
  return root;
}

export const ANTICHEAT = loadConfig();


const RAD2DEG = 180 / Math.PI;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const num = (v, fallback = 0) => (Number.isFinite(Number(v)) ? Number(v) : fallback);
const CHECK_LABELS = {
  aim: "Aim",
  turn: "RotationSnap",
  smooth: "RotationSmooth",
  angle: "BadPackets",
  rate: "Timer",
};
const COLORS = {
  gray: "\x1b[90m",
  purple: "\x1b[35m",
  deepPurple: "\x1b[38;5;54m",
  white: "\x1b[97m",
  reset: "\x1b[0m",
};
const COLOR_ENABLED = process.env.FORCE_COLOR === "1" ||
  (!process.env.NO_COLOR && Boolean(process.stdout?.isTTY));
const AC_TAG = COLOR_ENABLED
  ? `${COLORS.gray}[${COLORS.purple}Yokai${COLORS.deepPurple}AC${COLORS.gray}]${COLORS.reset}`
  : "[YokaiAC]";
const paint = (color, value) => COLOR_ENABLED
  ? `${COLORS[color]}${value}${COLORS.reset}`
  : String(value);
const acCount = (value) =>
  `${paint("gray", "[x")}${paint("purple", value)}${paint("gray", "]")}`;

function wrapDeg(delta) {
  let d = (delta + 180) % 360;
  if (d < 0) d += 360;
  return d - 180;
}

//符号变化次数零值不计数
function signChanges(values) {
  let prev = 0;
  let count = 0;
  for (const value of values) {
    const sign = Math.sign(value);
    if (!sign) continue;
    if (prev && sign !== prev) count++;
    prev = sign;
  }
  return count;
}

function dirOf(yaw, pitch) {
  const cp = Math.cos(pitch);
  return { x: -Math.sin(yaw) * cp, y: Math.sin(pitch), z: -Math.cos(yaw) * cp };
}

//视角夹角小角度用叉积
function angleDeg(yawA, pitchA, yawB, pitchB) {
  const a = dirOf(yawA, pitchA);
  const b = dirOf(yawB, pitchB);
  const dot = a.x * b.x + a.y * b.y + a.z * b.z;
  const cx = a.y * b.z - a.z * b.y;
  const cy = a.z * b.x - a.x * b.z;
  const cz = a.x * b.y - a.y * b.x;
  return Math.atan2(Math.hypot(cx, cy, cz), dot) * RAD2DEG;
}

const dot3 = (u, v) => u.x * v.x + u.y * v.y + u.z * v.z;
const norm3 = (u) => Math.hypot(u.x, u.y, u.z);

//射线与目标方向的角误差
export function shotPrecisionDeg(origin, dir, point) {
  if (!origin || !dir || !point) return null;
  const v = { x: point.x - origin.x, y: point.y - origin.y, z: point.z - origin.z };
  const len = norm3(v);
  if (len < 1e-6) return 0;
  const dot = dot3(dir, v);
  const cx = dir.y * v.z - dir.z * v.y;
  const cy = dir.z * v.x - dir.x * v.z;
  const cz = dir.x * v.y - dir.y * v.x;
  return Math.atan2(Math.hypot(cx, cy, cz), dot) * RAD2DEG;
}

function createState() {
  return {
    //切枪清空统计
    weapon: "",
    //输入视角采样
    samples: [],
    aim: {
      score: 0,
      shots: 0,
      recent: [],
      diverged: 0,
      precise: 0,
      prec: [],
      precEval: 0,
    },
    turn: {
      lastInput: null,
      pendingShots: [],
      attempts: 0,
      hits: 0,
      misses: 0,
    },
    smooth: {
      score: 0,
      hist: [],
      run: 0,
      runStartT: 0,
      longRun: false,
      lastRun: null,
      curveHist: [],
      curveSign: 0,
      curveRun: 0,
      curveStartT: 0,
      lastCurve: null,
      exp: {
        mode: 0,
        signY: 0,
        signP: 0,
        prevDy: 0,
        prevDp: 0,
        startT: 0,
        samples: 0,
        total: 0,
        ratiosY: [],
        ratiosP: [],
        flagged: false,
        last: null,
      },
    },
    //非法角度
    angle: { score: 0, prevSeen: null },
    //包间隔余额
    rate: { score: 0, balance: 0, lastT: 0, ignoreUntil: 0 },
    vl: {},
    lastFlagAt: {},
    aiVl: 0,
    lastAiFlagAt: 0,
    decayAt: 0,
    lastShotAt: 0,
    lastBigTurnAt: 0,
    lastBigTurnDeg: 0,
  };
}

export class AntiCheat {
  constructor(options = {}) {
    this.opts = {
      ...ANTICHEAT,
      ...options,
      aim: { ...ANTICHEAT.aim, ...(options.aim || {}) },
      turn: { ...ANTICHEAT.turn, ...(options.turn || {}) },
      smooth: { ...ANTICHEAT.smooth, ...(options.smooth || {}) },
      angle: { ...ANTICHEAT.angle, ...(options.angle || {}) },
      rate: { ...ANTICHEAT.rate, ...(options.rate || {}) },
      ai: { ...ANTICHEAT.ai, ...(options.ai || {}) },
    };
    this.states = new Map();
    this.ai = new AIDetector(this.opts.ai, {
      onFlag: (player, prob) => this.reportAI(player, prob),
    });
  }

  get enabled() {
    return this.opts.enabled !== false;
  }

  checkEnabled(group) {
    const cfg = this.opts[group];
    return cfg?.enabled !== false;
  }

  subEnabled(group, name) {
    const cfg = this.opts[group];
    return cfg?.[name] !== false;
  }

  //Bot跳过
  skip(player) {
    if (!player) return true;
    return !!(player.bot && !this.opts.checkBots);
  }

  stateKey(player) {
    if (player?.id !== undefined && player?.id !== null) return player.id;
    if (player?.uid !== undefined && player?.uid !== null) return `uid:${player.uid}`;
    return player;
  }

  stateFor(player) {
    const key = this.stateKey(player);
    let st = this.states.get(key);
    if (!st) {
      st = createState();
      this.states.set(key, st);
    }
    return st;
  }

  remove(player) {
    if (player) {
      this.states.delete(this.stateKey(player));
      this.ai?.remove(player);
    }
  }

  //重生旧采样清空
  onSpawn(player) {
    this.ai?.onSpawn(player);
    const st = this.states.get(this.stateKey(player));
    if (!st) return;
    st.samples.length = 0;
    st.turn.lastInput = null;
    st.turn.pendingShots.length = 0;
    st.smooth.hist.length = 0;
    st.smooth.run = 0;
    st.smooth.runStartT = 0;
    st.smooth.longRun = false;
    st.smooth.lastRun = null;
    st.smooth.curveHist.length = 0;
    st.smooth.curveSign = 0;
    st.smooth.curveRun = 0;
    st.smooth.curveStartT = 0;
    st.smooth.lastCurve = null;
    st.smooth.exp.mode = 0;
    st.smooth.exp.signY = 0;
    st.smooth.exp.signP = 0;
    st.smooth.exp.prevDy = 0;
    st.smooth.exp.prevDp = 0;
    st.smooth.exp.startT = 0;
    st.smooth.exp.samples = 0;
    st.smooth.exp.total = 0;
    st.smooth.exp.ratiosY.length = 0;
    st.smooth.exp.ratiosP.length = 0;
    st.smooth.exp.flagged = false;
    st.smooth.exp.last = null;
    st.aim.score = 0;
    st.smooth.score = 0;
    st.angle.score = 0;
    st.rate.score = 0;
    st.rate.balance = 0;
    st.rate.lastT = 0;
    st.rate.ignoreUntil = 0;
    st.aim.recent.length = 0;
    st.aim.prec.length = 0;
    st.aim.precEval = 0;
    st.weapon = "";
    st.lastShotAt = 0;
    st.lastBigTurnAt = 0;
    st.lastBigTurnDeg = 0;
    //vl保留
  }

  decay(st, now) {
    if (!st.decayAt) { st.decayAt = now; return; }
    const elapsed = now - st.decayAt;
    if (elapsed < 100) return;
    const factor = Math.pow(0.5, elapsed / Math.max(1000, num(this.opts.scoreHalfLifeMs, 8000)));
    st.aim.score *= factor;
    st.smooth.score *= factor;
    st.angle.score *= factor;
    st.rate.score *= factor;
    st.decayAt = now;
  }

  addScore(st, group, weight) {
    if (!(weight > 0)) return;
    const bucket = st[group];
    if (!bucket) return;
    bucket.score += weight;
  }

  maybeReport(st, player, group) {
    const cfg = this.opts[group];
    if (!cfg || cfg.enabled === false) return;
    if (st[group].score < cfg.threshold) return;
    st[group].score = 0;
    this.report(player, CHECK_LABELS[group] || group);
  }

  report(player, check) {
    const st = this.states.get(this.stateKey(player));
    if (!st) return;
    const now = Date.now();
    if (now - (st.lastFlagAt[check] || 0) < num(this.opts.reportCooldownMs, 2000)) return;
    st.lastFlagAt[check] = now;
    st.vl[check] = Math.min(99, (st.vl[check] || 0) + 1);
    console.warn(
      `${AC_TAG} ${paint("white", player.name)} ${paint("gray", "failed")} ` +
      `${paint("purple", check)} ${acCount(st.vl[check])}`,
    );
  }

  reportAI(player, prob) {
    if (!this.checkEnabled("ai")) return;
    const st = this.states.get(this.stateKey(player));
    if (!st) return;
    const now = Date.now();
    const cfg = this.opts.ai;
    if (now - st.lastAiFlagAt < num(cfg.reportCooldownMs, 5000)) return;
    st.lastAiFlagAt = now;
    st.aiVl = Math.min(99, st.aiVl + 1);
    const aiProb = `(AI p=${num(prob, 0).toFixed(3)})`;
    console.warn(
      `${AC_TAG} ${paint("white", player.name)} ${paint("gray", "failed")} ` +
      `${paint("purple", "AI")} ${acCount(st.aiVl)} ${paint("gray", aiProb)}`,
    );
  }

  //采样与转头检测
  onInput(player, input, now = Date.now()) {
    if (!this.enabled || this.skip(player) || !input || typeof input !== "object") return;
    const st = this.states.get(this.stateKey(player)) || this.stateFor(player);
    this.decay(st, now);

    //30Hz是原版上限
    if (this.checkEnabled("rate") && this.subEnabled("rate", "interval")) {
      this.analyzeRate(st, player, now);
    }

    const yaw = Number(input.yaw);
    const pitch = Number(input.pitch);
    if (!Number.isFinite(yaw) || !Number.isFinite(pitch)) {
      //正常客户端发不出非有限角度
      if (this.checkEnabled("angle") && this.subEnabled("angle", "nonFinite")) {
        this.addScore(st, "angle", this.opts.angle.nonFiniteWeight);
        this.maybeReport(st, player, "angle");
      }
      return;
    }

    //客户端把pitch夹在±1.5rad
    if (this.checkEnabled("angle") && this.subEnabled("angle", "pitch")) {
      this.analyzeAngle(st, player, pitch);
    }

    //AI只看原始视角增量
    if (this.checkEnabled("ai")) {
      this.ai?.onInput(player, { yaw, pitch, seq: input.seq }, now);
    }

    const sample = {
      t: now,
      yaw,
      pitch: clamp(pitch, -Math.PI / 2, Math.PI / 2),
    };

    const prev = st.samples.length ? st.samples[st.samples.length - 1] : null;
    //先结算上一枪的shot后第一包
    if (this.checkEnabled("turn") && this.subEnabled("turn", "flick")) {
      this.resolveFlickShots(st, player, sample, now);
    }
    if (prev) {
      if (this.checkEnabled("aim") && this.subEnabled("aim", "flick")) {
        this.trackBigTurn(st, prev, sample);
      }
      if (this.checkEnabled("smooth")) {
        this.analyzeSmooth(st, player, prev, sample);
      }
    }
    st.turn.lastInput = sample;

    st.samples.push(sample);
    const max = Math.max(8, num(this.opts.maxSamples, 64));
    while (st.samples.length > max) st.samples.shift();
  }

  //取一段时间前的视角
  viewAgo(player, now, ms) {
    const st = this.states.get(this.stateKey(player));
    if (!st || !st.samples.length) return null;
    const cutoff = now - ms;
    for (let i = st.samples.length - 1; i >= 0; i--) {
      if (st.samples[i].t <= cutoff) return st.samples[i];
    }
    return null;
  }

  //把开枪相关的大幅/匀速转动算作可疑
  aimContext(st, t) {
    const window = num(this.opts.turn.aimWindowMs, 400);
    return st.lastShotAt > 0 && Math.abs(t - st.lastShotAt) <= window;
  }

  //Aim甩枪命中信号不参与RotationSnap统计
  trackBigTurn(st, prev, sample) {
    const step = angleDeg(prev.yaw, prev.pitch, sample.yaw, sample.pitch);
    if (step >= num(this.opts.turn.bigTurnAngleDeg, 100)) {
      st.lastBigTurnAt = sample.t;
      st.lastBigTurnDeg = step;
    }
  }

  //记录shot前input包与后shot包再判断
  recordFlickShot(st, info, now) {
    const cfg = this.opts.turn;
    const pre = st.turn.lastInput;
    if (!pre) return;
    const preAge = now - pre.t;
    if (preAge < 0 || preAge > num(cfg.flickPreMaxAgeMs, 120)) return;

    const shotYaw = Number(info.yaw);
    const shotPitch = Number(info.pitch);
    if (!Number.isFinite(shotYaw) || !Number.isFinite(shotPitch)) return;

    st.turn.pendingShots.push({
      pre,
      shotT: now,
      shotYaw,
      shotPitch,
      hit: Boolean(info.victim),
    });
    while (st.turn.pendingShots.length > 8) st.turn.pendingShots.shift();
  }

  resolveFlickShots(st, player, sample, now) {
    const cfg = this.opts.turn;
    const pending = st.turn.pendingShots;
    if (!pending.length) return;

    const maxPost = num(cfg.flickPostMaxAgeMs, 150);
    let resolved = false;
    for (const item of pending) {
      const preAge = item.shotT - item.pre.t;
      const postAge = now - item.shotT;
      if (preAge < 0 || preAge > num(cfg.flickPreMaxAgeMs, 120)) continue;
      if (postAge < 0 || postAge > maxPost) continue;

      const gap = angleDeg(
        item.pre.yaw, item.pre.pitch,
        sample.yaw, sample.pitch,
      );
      const shotDelta = angleDeg(
        item.pre.yaw, item.pre.pitch,
        item.shotYaw, item.shotPitch,
      );

      if (gap > num(cfg.flickPrePostMaxDeg, 35)) continue;
      if (shotDelta < num(cfg.flickMinShotDeg, 25)) continue;
      if (shotDelta <= gap + num(cfg.flickMinExcessDeg, 10)) continue;

      st.turn.attempts++;
      if (item.hit) st.turn.hits++;
      else st.turn.misses++;
      resolved = true;
    }

    pending.length = 0;
    if (resolved) this.maybeReportFlick(st, player);
  }

  maybeReportFlick(st, player) {
    if (!this.checkEnabled("turn") || !this.subEnabled("turn", "flick")) return;
    const cfg = this.opts.turn;
    if (st.turn.attempts < num(cfg.flickMinAttempts, 10)) return;
    if (st.turn.hits <= st.turn.misses) return;
    this.report(player, CHECK_LABELS.turn || "RotationSnap");
  }

  analyzeAngle(st, player, pitch) {
    if (!this.checkEnabled("angle") || !this.subEnabled("angle", "pitch")) return;
    const cfg = this.opts.angle;
    const limit = (num(cfg.pitchLimitDeg, 86.5) * Math.PI) / 180;
    if (Math.abs(pitch) > limit) {
      this.addScore(st, "angle", cfg.pitchWeight);
      this.maybeReport(st, player, "angle");
    }
  }

  //用余额高延迟不误报
  analyzeRate(st, player, now) {
    if (!this.checkEnabled("rate") || !this.subEnabled("rate", "interval")) return;
    const cfg = this.opts.rate;
    const expectedMs = Math.max(5, num(cfg.expectedIntervalMs, 1000 / 30));
    const maxAheadMs = Math.max(expectedMs * 3, num(cfg.maxAheadMs, 200));
    const maxBehindMs = Math.max(maxAheadMs, num(cfg.maxBehindMs, 2000));
    const leakMs = Math.max(0, num(cfg.leakPerPacketMs, 0.75));
    const resetGapMs = Math.max(200, num(cfg.resetGapMs, 1000));
    const maxIgnoreMs = Math.max(0, num(cfg.maxIgnoreMs, 5000));

    const rate = st.rate;
    if (!rate.lastT) {
      rate.lastT = now;
      rate.balance = 0;
      return;
    }
    const dt = now - rate.lastT;
    if (dt < 0) return;

    //长卡顿/切后台后的补发不参与计时
    if (dt > resetGapMs) {
      rate.lastT = now;
      rate.balance = 0;
      rate.ignoreUntil = now + Math.min(dt, maxIgnoreMs);
      return;
    }
    rate.lastT = now;
    if (rate.ignoreUntil && now < rate.ignoreUntil) {
      rate.balance = 0;
      return;
    }

    //漏桶抵消固定间隔的浮点漂移
    rate.balance = clamp(
      rate.balance + expectedMs - dt - leakMs,
      -maxBehindMs,
      maxAheadMs * 2,
    );

    if (rate.balance >= maxAheadMs) {
      rate.balance -= maxAheadMs;
      this.addScore(st, "rate", cfg.weight);
      this.maybeReport(st, player, "rate");
    }
  }

  //曲线平滑
  analyzeCurveSmooth(st, prev, sample, delta) {
    if (!this.checkEnabled("smooth") || !this.subEnabled("smooth", "curve")) return;
    const cfg = this.opts.smooth;
    const dt = sample.t - prev.t;
    if (dt <= 0) return;

    const c = st.smooth;
    const reset = () => {
      c.curveHist.length = 0;
      c.curveSign = 0;
      c.curveRun = 0;
      c.curveStartT = 0;
    };

    if (dt > this.opts.turn.maxGapMs ||
        Math.abs(delta) > num(cfg.curveMaxStepDeg, 60)) {
      reset();
      return;
    }

    const sign = Math.sign(delta);
    if (c.curveSign && sign !== c.curveSign) reset();
    c.curveSign = sign;
    c.curveHist.push({ t: sample.t, d: delta });
    if (c.curveHist.length === 1) c.curveStartT = prev.t;

    const window = Math.max(6, num(cfg.curveWindow, 12));
    while (c.curveHist.length > window + 4) c.curveHist.shift();
    if (c.curveHist.length < window) return;

    const win = c.curveHist.slice(-window);
    let sgn = 0;
    let sum = 0;
    let minAbs = Infinity;
    let minD = Infinity;
    let maxD = -Infinity;
    for (const it of win) {
      const s = Math.sign(it.d);
      if (s === 0 || (sgn !== 0 && s !== sgn)) { reset(); return; }
      sgn = s;
      sum += Math.abs(it.d);
      minAbs = Math.min(minAbs, Math.abs(it.d));
      minD = Math.min(minD, it.d);
      maxD = Math.max(maxD, it.d);
    }

    const mean = sum / win.length;
    if (mean < num(cfg.curveMinMeanDeltaDeg, 1.8) ||
        minAbs < num(cfg.curveMinDeltaDeg, 0.2)) {
      reset();
      return;
    }

    let variance = 0;
    for (const it of win) {
      const v = Math.abs(it.d) - mean;
      variance += v * v;
    }
    const cv = Math.sqrt(variance / win.length) / mean;
    const rangeRatio = (maxD - minD) / mean;
    if (cv < num(cfg.curveMinCV, 0.08) ||
        rangeRatio < num(cfg.curveMinRangeRatio, 0.45)) {
      reset();
      return;
    }

    const acc = [];
    for (let i = 1; i < win.length; i++) acc.push(win[i].d - win[i - 1].d);
    let accSum = 0;
    for (const a of acc) accSum += Math.abs(a);
    const meanAcc = accSum / acc.length;
    const accRatio = meanAcc / mean;
    if (accRatio < num(cfg.curveMinAccelRatio, 0.015) ||
        accRatio > num(cfg.curveMaxAccelRatio, 0.6)) {
      reset();
      return;
    }

    const jerk = [];
    for (let i = 1; i < acc.length; i++) jerk.push(acc[i] - acc[i - 1]);
    let jerkSum = 0;
    for (const j of jerk) jerkSum += Math.abs(j);
    const meanJerk = jerkSum / jerk.length;
    const jerkRatio = meanJerk / Math.max(meanAcc, 1e-9);
    if (jerkRatio > num(cfg.curveMaxJerkRatio, 0.35)) {
      reset();
      return;
    }

    const accChanges = signChanges(acc);
    const jerkChanges = signChanges(jerk);
    if (accChanges > num(cfg.curveMaxAccelSignChanges, 1) ||
        jerkChanges > num(cfg.curveMaxJerkSignChanges, 1)) {
      reset();
      return;
    }

    c.curveRun++;
    c.lastCurve = {
      endT: sample.t,
      samples: c.curveRun,
      duration: sample.t - c.curveStartT,
      mean,
      cv,
      accRatio,
      jerkRatio,
      accChanges,
      jerkChanges,
    };
  }

  //双轴同比例指数收敛
  analyzeExpSmooth(st, player, prev, sample, dyaw, dpitch) {
    if (!this.checkEnabled("smooth") || !this.subEnabled("smooth", "exp")) return;
    const cfg = this.opts.smooth;
    const e = st.smooth.exp;
    const reset = () => {
      e.mode = 0;
      e.signY = 0;
      e.signP = 0;
      e.prevDy = 0;
      e.prevDp = 0;
      e.startT = 0;
      e.samples = 0;
      e.total = 0;
      e.ratiosY.length = 0;
      e.ratiosP.length = 0;
      e.flagged = false;
    };
    const begin = (mode, sy, sp, ay, ap) => {
      e.mode = mode;
      e.signY = sy;
      e.signP = sp;
      e.prevDy = ay;
      e.prevDp = ap;
      e.startT = prev.t;
      e.samples = 1;
      e.total = mode === 2 ? ay + ap : (mode === 1 ? ay : ap);
      e.ratiosY.length = 0;
      e.ratiosP.length = 0;
      e.flagged = false;
    };

    const dt = sample.t - prev.t;
    if (dt <= 0 || dt > this.opts.turn.maxGapMs) {
      reset();
      return;
    }

    const ay = Math.abs(dyaw);
    const ap = Math.abs(dpitch);
    const minD = num(cfg.expMinDeltaDeg, 0.2);
    const idleMax = num(cfg.expIdleAxisMaxDeg, 0.6);
    const actY = ay >= minD;
    const actP = ap >= minD;
    if (!actY && !actP) {
      reset();
      return;
    }
    if (actY && !actP && ap > idleMax) {
      reset();
      return;
    }
    if (!actY && actP && ay > idleMax) {
      reset();
      return;
    }

    const sy = actY ? Math.sign(dyaw) : 0;
    const sp = actP ? Math.sign(dpitch) : 0;
    if ((actY && !sy) || (actP && !sp)) {
      reset();
      return;
    }
    const mode = actY && actP ? 2 : (actY ? 1 : 3);

    if (!e.mode) {
      begin(mode, sy, sp, ay, ap);
      return;
    }
    if (e.mode === 2 && (actY || actP)) {
      if ((actY && e.signY && sy !== e.signY) ||
          (actP && e.signP && sp !== e.signP)) {
        begin(2, sy, sp, ay, ap);
        return;
      }
    } else if (e.mode !== mode ||
        (actY && e.signY && sy !== e.signY) ||
        (actP && e.signP && sp !== e.signP)) {
      begin(mode, sy, sp, ay, ap);
      return;
    }

    const minR = num(cfg.expMinRatio, 0.30);
    const maxR = num(cfg.expMaxRatio, 0.98);
    const maxDiff = num(cfg.expMaxAxisDiff, 0.06);
    //原版客户端是固定30Hz直接用相邻包位移
    const ry = actY ? ay / e.prevDy : 1;
    const rp = actP ? ap / e.prevDp : 1;
    if ((actY && (ry < minR || ry > maxR)) ||
        (actP && (rp < minR || rp > maxR)) ||
        (mode === 2 && actY && actP && Math.abs(ry - rp) > maxDiff)) {
      begin(mode, sy, sp, ay, ap);
      return;
    }

    if (actY) e.ratiosY.push(ry);
    if (actP) e.ratiosP.push(rp);
    while (e.ratiosY.length > 24) e.ratiosY.shift();
    while (e.ratiosP.length > 24) e.ratiosP.shift();
    e.prevDy = ay;
    e.prevDp = ap;
    e.samples++;
    e.total += (actY ? ay : 0) + (actP ? ap : 0);

    const duration = sample.t - e.startT;
    const all = e.ratiosY.concat(e.ratiosP);
    const n = all.length;
    if (!n) {
      begin(mode, sy, sp, ay, ap);
      return;
    }
    const meanY = e.ratiosY.length ? e.ratiosY.reduce((a, b) => a + b, 0) / e.ratiosY.length : 0;
    const meanP = e.ratiosP.length ? e.ratiosP.reduce((a, b) => a + b, 0) / e.ratiosP.length : 0;
    const mean = all.reduce((a, b) => a + b, 0) / n;
    let variance = 0;
    for (const r of all) variance += (r - mean) ** 2;
    const std = Math.sqrt(variance / n);
    const axisDiff = mode === 2 ? Math.abs(meanY - meanP) : 0;

    if (!e.flagged &&
        e.samples >= num(cfg.expMinSamples, 5) &&
        duration >= num(cfg.expMinDurationMs, 130) &&
        e.total >= num(cfg.expMinTurnDeg, 6) &&
        std <= num(cfg.expMaxRatioStd, 0.06) &&
        axisDiff <= maxDiff) {
      e.flagged = true;
      e.last = {
        endT: sample.t,
        samples: e.samples,
        duration,
        meanRatio: mean,
        axisDiff,
        std,
        total: e.total,
        single: mode !== 2,
      };
      const weight = mode === 2
        ? num(cfg.expWeight, 3.6)
        : num(cfg.expSingleWeight, 3.6);
      this.addScore(st, "smooth", weight);
      this.maybeReport(st, player, "smooth");
    }

    //持续收敛时保留最近一次终点
    if (e.flagged && e.last) {
      e.last.endT = sample.t;
      e.last.samples = e.samples;
      e.last.duration = duration;
      e.last.total = e.total;
    }
  }

  //转头平滑
  analyzeSmooth(st, player, prev, sample) {
    if (!this.checkEnabled("smooth")) return;
    const cfg = this.opts.smooth;
    const dt = sample.t - prev.t;
    if (dt <= 0) return;

    const hist = st.smooth.hist;
    const reset = () => {
      hist.length = 0;
      st.smooth.run = 0;
      st.smooth.runStartT = 0;
      st.smooth.longRun = false;
    };

    //取主轴位移
    const dyaw = wrapDeg((sample.yaw - prev.yaw) * RAD2DEG);
    const dpitch = (sample.pitch - prev.pitch) * RAD2DEG;
    const delta = Math.abs(dyaw) >= Math.abs(dpitch) ? dyaw : dpitch;

    if (this.subEnabled("smooth", "exp")) {
      this.analyzeExpSmooth(st, player, prev, sample, dyaw, dpitch);
    }
    if (this.subEnabled("smooth", "curve")) {
      this.analyzeCurveSmooth(st, prev, sample, delta);
    }

    if (!this.subEnabled("smooth", "run")) {
      reset();
      return;
    }

    if (dt > this.opts.turn.maxGapMs || Math.abs(delta) > 45) { reset(); return; }

    hist.push({ t: sample.t, d: delta });
    //停顿/反向会重置
    if (hist.length === 1) st.smooth.runStartT = prev.t;
    while (hist.length > cfg.window + 8) hist.shift();
    if (hist.length < cfg.window) return;

    const win = hist.slice(-cfg.window);
    let sign = 0;
    let sum = 0;
    let minAbs = Infinity;
    for (const it of win) {
      const s = Math.sign(it.d);
      if (s === 0 || (sign !== 0 && s !== sign)) { reset(); return; }
      sign = s;
      sum += Math.abs(it.d);
      minAbs = Math.min(minAbs, Math.abs(it.d));
    }
    //有停顿/抖动就不算机器匀速
    if (minAbs < 0.25) { reset(); return; }

    const mean = sum / win.length;
    if (mean < cfg.minMeanDeltaDeg) { reset(); return; }

    let variance = 0;
    for (const it of win) {
      const v = Math.abs(it.d) - mean;
      variance += v * v;
    }
    const std = Math.sqrt(variance / win.length);
    const cv = std / mean;

    let jerk = 0;
    for (let i = 1; i < win.length; i++) jerk += Math.abs(win[i].d - win[i - 1].d);
    const jerkRatio = jerk / ((win.length - 1) * mean);

    if (cv > cfg.maxCV || jerkRatio > cfg.maxJerkRatio) {
      //打断连续段
      reset();
      return;
    }

    const aimCtx = this.aimContext(st, sample.t);
    st.smooth.run++;

    const duration = sample.t - st.smooth.runStartT;
    //留给开枪时判断
    st.smooth.lastRun = {
      endT: sample.t,
      samples: st.smooth.run,
      duration,
      mean,
      cv,
    };

    //人类无法长时间零方差
    if (this.subEnabled("smooth", "longRun") && aimCtx && !st.smooth.longRun &&
        duration >= cfg.longRunMs && st.smooth.run >= cfg.longRunMinSamples) {
      st.smooth.longRun = true;
      this.addScore(st, "smooth", cfg.longRunWeight);
      this.maybeReport(st, player, "smooth");
    }

    this.maybeReport(st, player, "smooth");
  }

  //启发式自瞄
  onShot(player, info) {
    if (!this.enabled || this.skip(player) || !info) return;
    const st = this.states.get(this.stateKey(player)) || this.stateFor(player);
    const now = num(info.now, Date.now());
    this.decay(st, now);
    const cfg = this.opts.aim;

    st.lastShotAt = now;
    if (this.checkEnabled("ai")) {
      this.ai?.onShot(player, { now });
    }

    const shotYaw = Number(info.yaw);
    const shotPitch = Number(info.pitch);
    if (!Number.isFinite(shotYaw) || !Number.isFinite(shotPitch)) return;
    if (this.checkEnabled("turn") && this.subEnabled("turn", "flick")) {
      this.recordFlickShot(st, info, now);
    }

    const aimOn = this.checkEnabled("aim");

    //换枪清空
    const weapon = typeof info.weapon === "string" ? info.weapon : "";
    if (weapon && st.weapon !== weapon) {
      st.weapon = weapon;
      st.aim.recent.length = 0;
      st.aim.prec.length = 0;
    }
    const precisionOk = !weapon || !(cfg.excludedPrecisionWeapons || []).includes(weapon);

    if (aimOn && this.subEnabled("aim", "view") && st.samples.length) {
      let bestExcess = Infinity;
      const extra = num(cfg.weaponExtraToleranceDeg?.[weapon], 0);
      for (let i = st.samples.length - 1; i >= 0; i--) {
        const s = st.samples[i];
        const ageMs = now - s.t;
        if (ageMs > cfg.viewSearchMs) break;
        if (ageMs < -num(cfg.viewFutureMs, 30)) continue;
        const gap = angleDeg(s.yaw, s.pitch, shotYaw, shotPitch);
        const p = i > 0 ? st.samples[i - 1] : null;
        let speed = 0;
        if (p && s.t > p.t) speed = (angleDeg(p.yaw, p.pitch, s.yaw, s.pitch) * 1000) / (s.t - p.t);
        const ageSec = Math.abs(ageMs) / 1000;
        const allowed = Math.min(
          num(cfg.viewMaxToleranceDeg, 60),
          num(cfg.viewBaseToleranceDeg, 3.5) + extra +
            speed * (ageSec + num(cfg.viewSampleAgeSec, 0.02)),
        );
        if (gap - allowed < bestExcess) bestExcess = gap - allowed;
      }
      if (bestExcess > 0) {
        st.aim.diverged++;
        this.addScore(st, "aim", clamp(0.8 + bestExcess / 6, 0.8, 2.4));
      }
    }

    const dist = num(info.distance, 0);

    if (aimOn && precisionOk) {

      //人类做不到的命中精度
      if (this.subEnabled("aim", "precision") &&
          info.victim && info.head && dist >= cfg.precisionMinDistance &&
          num(info.targetSpeed) >= cfg.precisionMinTargetSpeed &&
          Number.isFinite(Number(info.precisionDeg)) &&
          num(info.precisionDeg) <= cfg.precisionDeg) {
        st.aim.precise++;
        this.addScore(st, "aim", (dist >= 30 ? 1.0 : 0.6) + (num(info.targetSpeed) >= 2 ? 0.3 : 0));
      }

      //机器误差过于恒定
      if (this.subEnabled("aim", "precisionStd") &&
          info.victim && dist >= cfg.precisionMinDistance &&
          num(info.targetSpeed) >= cfg.precisionMinTargetSpeed &&
          Number.isFinite(Number(info.precisionDeg))) {
        st.aim.prec.push(num(info.precisionDeg));
        while (st.aim.prec.length > cfg.precisionStdWindow) st.aim.prec.shift();
        st.aim.precEval++;
        if (st.aim.prec.length >= cfg.precisionStdWindow && st.aim.precEval % cfg.precisionStdStep === 0) {
          const n = st.aim.prec.length;
          const mean = st.aim.prec.reduce((a, b) => a + b, 0) / n;
          const variance = st.aim.prec.reduce((a, b) => a + (b - mean) ** 2, 0) / n;
          const std = Math.sqrt(variance);
          if (mean <= cfg.precisionStdMaxMean && std <= cfg.precisionStdMaxStd) {
            this.addScore(st, "aim", cfg.precisionStdWeight);
          }
        }
      }

      //远距离爆头率异常
      if (this.subEnabled("aim", "headRate")) {
        st.aim.shots++;
        const rec = st.aim.recent;
        rec.push({ head: !!info.head, dist, victim: !!info.victim });
        while (rec.length > cfg.headRateWindow) rec.shift();
        if (rec.length >= cfg.headRateWindow && st.aim.shots % cfg.headRateStep === 0) {
          const headRate = rec.filter((r) => r.head).length / rec.length;
          const long = rec.filter((r) => r.victim && r.dist >= cfg.headRateLongDistance);
          const longHeadRate = long.length ? long.filter((r) => r.head).length / long.length : 0;
          if (headRate >= cfg.headRateThreshold && long.length >= cfg.headRateMinLongShots &&
              longHeadRate >= cfg.headRateLongThreshold) {
            this.addScore(st, "aim", cfg.headRateWeight);
          }
        }
      }

    }

    //曲线平滑后命中加速度近似直线且高频抖动极低
    const scfg = this.opts.smooth;
    const smoothOn = this.checkEnabled("smooth");
    const curve = smoothOn && this.subEnabled("smooth", "curve") ? st.smooth.lastCurve : null;
    const run = smoothOn && this.subEnabled("smooth", "run") ? st.smooth.lastRun : null;
    if (info.victim && curve &&
        now - curve.endT <= num(scfg.curveShotWindowMs, 160) &&
        curve.duration >= num(scfg.curveMinRunDurationMs, 300) &&
        curve.samples >= num(scfg.curveMinRunSamples, 2)) {
      this.addScore(st, "smooth",
        num(scfg.curveShotWeight, 2.4) + (info.head ? num(scfg.curveHeadBonus, 0.7) : 0));
      this.maybeReport(st, player, "smooth");
    } else if (info.victim && run && now - run.endT <= scfg.shotWindowMs &&
        run.duration >= scfg.minRunDurationMs && run.samples >= scfg.minRunSamples) {
      //匀速转头后命中
      this.addScore(st, "smooth", scfg.shotRunWeight + (info.head ? scfg.shotHeadBonus : 0));
      this.maybeReport(st, player, "smooth");
    }

    //双轴指数收敛后命中
    if (smoothOn && this.subEnabled("smooth", "exp")) {
      const exp = st.smooth.exp.last;
      if (info.victim && exp &&
          now - exp.endT <= num(scfg.expShotWindowMs, 200)) {
        this.addScore(st, "smooth",
          num(scfg.expShotWeight, 1.4) + (info.head ? num(scfg.expHeadBonus, 0.4) : 0));
        this.maybeReport(st, player, "smooth");
      }
    }

    //甩枪后极短时间爆头
    if (aimOn && this.subEnabled("aim", "flick") && precisionOk &&
        info.victim && info.head && dist >= cfg.flickMinDistance &&
        st.lastBigTurnAt && now - st.lastBigTurnAt <= cfg.flickWindowMs &&
        st.lastBigTurnDeg >= cfg.flickAngleDeg) {
      this.addScore(st, "aim", cfg.flickWeight);
    }

    this.maybeReport(st, player, "aim");
  }
}
