@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [YokaiAC] 未找到 Node.js，请先安装 Node.js 18^+ 并加入 PATH。
  if not "%YOKAI_NO_PAUSE%"=="1" pause
  exit /b 1
)

if not exist "src\room.js" (
  echo [YokaiAC] 当前目录不是 GoldenHour 服务端根目录：缺少 src\room.js
  if not "%YOKAI_NO_PAUSE%"=="1" pause
  exit /b 1
)

node -e "const fs=require('fs');const path=require('path');const f=process.argv[1];const s=fs.readFileSync(f,'utf8');const m='###YOKAI_AC_JS###';const i=s.lastIndexOf(m);if(i<0)process.exit(2);eval(s.slice(i+m.length));" "%~f0"
if errorlevel 1 (
  echo [YokaiAC] 注入失败，原文件未完成替换或依赖缺失。
  if not "%YOKAI_NO_PAUSE%"=="1" pause
  exit /b 1
)

node --check "src\http.js"
if errorlevel 1 (
  echo [YokaiAC] http.js 语法检查失败。
  if not "%YOKAI_NO_PAUSE%"=="1" pause
  exit /b 1
)

node --check "src\room.js"
if errorlevel 1 (
  echo [YokaiAC] room.js 语法检查失败。
  if not "%YOKAI_NO_PAUSE%"=="1" pause
  exit /b 1
)

echo [YokaiAC] 完成：http.js / room.js 已注入，语法检查通过。
if not "%YOKAI_NO_PAUSE%"=="1" pause
exit /b 0

###YOKAI_AC_JS###
const root = path.resolve(process.cwd());
const src = path.join(root, "src");
const httpPath = path.join(src, "http.js");
const roomPath = path.join(src, "room.js");

function fail(message) {
  console.error(`[YokaiAC] ${message}`);
  process.exit(1);
}

function read(file) {
  if (!fs.existsSync(file)) fail(`找不到文件：${file}`);
  return fs.readFileSync(file, "utf8");
}

function replaceOnce(text, from, to, label, sentinel) {
  if (sentinel && text.includes(sentinel)) return { text, changed: false };
  const index = text.indexOf(from);
  if (index < 0) fail(`找不到${label}锚点，原版文件可能已被改过：${from.split("\n")[0]}`);
  if (text.indexOf(from, index + 1) >= 0) fail(`${label}锚点不唯一：${from.split("\n")[0]}`);
  return {
    text: text.slice(0, index) + to + text.slice(index + from.length),
    changed: true,
  };
}

function removeOnce(text, from, label) {
  const index = text.indexOf(from);
  if (index < 0) return { text, changed: false };
  if (text.indexOf(from, index + 1) >= 0) fail(`${label}出现多次，拒绝自动删除`);
  return { text: text.slice(0, index) + text.slice(index + from.length), changed: true };
}

function writeWithBackup(file, before, after) {
  if (before === after) return false;
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  fs.copyFileSync(file, `${file}.bak-${stamp}`);
  fs.writeFileSync(file, after, "utf8");
  return true;
}

const required = [
  path.join(src, "anticheat.js"),
  path.join(src, "anticheat.cfg"),
  path.join(src, "ai", "detector.js"),
];
for (const file of required) {
  if (!fs.existsSync(file)) fail(`缺少反作弊依赖：${file}`);
}

let http = read(httpPath);
const httpFrom = `      if (input) {
        player.input = input;
        player.ack = input.seq;
      }`;
const httpTo = `      if (input) room.handleInput(player, input);`;
const httpResult = replaceOnce(
  http,
  httpFrom,
  httpTo,
  "http.js onBinary",
  "room.handleInput(player, input)",
);
http = httpResult.text;

let room = read(roomPath);
const roomImportFrom = `import { MATCH, WEAPONS, WEAPON_SPECS, weaponSpec } from "./config.js";`;
const roomImportTo = `${roomImportFrom}
import { AntiCheat, shotPrecisionDeg } from "./anticheat.js";`;
const importResult = replaceOnce(
  room,
  roomImportFrom,
  roomImportTo,
  "room.js import",
  `from "./anticheat.js"`,
);
room = importResult.text;

const spawnFrom = `    if (this.room.testMode && !this.bot) this.reserve = 9999;`;
const spawnTo = `${spawnFrom}
    this.room.anticheat?.onSpawn(this);`;
const spawnResult = replaceOnce(
  room,
  spawnFrom,
  spawnTo,
  "room.js spawn",
  "this.room.anticheat?.onSpawn(this)",
);
room = spawnResult.text;

const ctorFrom = `    this.world = new World(map?.world?.colliders || [], this.bounds);`;
const ctorTo = `${ctorFrom}
    this.anticheat = new AntiCheat();`;
const ctorResult = replaceOnce(
  room,
  ctorFrom,
  ctorTo,
  "room.js constructor",
  "this.anticheat = new AntiCheat()",
);
room = ctorResult.text;

const dropFrom = `    p.connected = false;
    p.conn = null;
    this.players.delete(playerId);`;
const dropTo = `    p.connected = false;
    p.conn = null;
    this.anticheat.remove(p);
    this.players.delete(playerId);`;
const dropResult = replaceOnce(
  room,
  dropFrom,
  dropTo,
  "room.js dropPlayer",
  "this.anticheat.remove(p)",
);
room = dropResult.text;

const handleFrom = `  handleCommand(player, msg) {`;
const handleTo = `  handleInput(player, input) {
    if (!player || !input) return;
    player.input = input;
    player.ack = input.seq;
    this.anticheat.onInput(player, input, Date.now());
  }

  handleCommand(player, msg) {`;
const handleResult = replaceOnce(
  room,
  handleFrom,
  handleTo,
  "room.js handleCommand",
  "handleInput(player, input)",
);
room = handleResult.text;

const shotFrom = `    const shotEvent = {`;
const shotTo = `    const victimHeight = best ? heightOf(best.state) : 0;
    const head = !!best && origin.y + dir.y * best.t > best.state.y + victimHeight - 0.25;
    const headPoint = best
      ? { x: best.state.x, y: best.state.y + victimHeight - 0.15, z: best.state.z }
      : null;

    let lookChanged = false;
    const prevView = best ? this.anticheat.viewAgo(player, now, 200) : null;
    if (prevView) {
      const cp = Math.cos(prevView.pitch);
      const prevDir = {
        x: -Math.sin(prevView.yaw) * cp,
        y: Math.sin(prevView.pitch),
        z: -Math.cos(prevView.yaw) * cp,
      };
      const proxy = {
        pos: { x: best.state.x, y: best.state.y, z: best.state.z },
        crouch: best.state.crouch,
        sliding: best.state.sliding,
      };
      lookChanged = rayPlayer(origin, prevDir, proxy, victimHeight) === null;
    }
    this.anticheat.onShot(player, {
      now,
      tick: shotTick,
      weapon: player.weapon,
      yaw,
      pitch,
      origin,
      victim: best?.target || null,
      lookChanged,
      distance: best?.t ?? null,
      head,
      precisionDeg: headPoint ? shotPrecisionDeg(origin, dir, headPoint) : null,
      targetSpeed: best ? Math.hypot(best.target.vel.x, best.target.vel.z) : 0,
    });

    const shotEvent = {`;
const shotResult = replaceOnce(
  room,
  shotFrom,
  shotTo,
  "room.js shot",
  "this.anticheat.onShot(player, {",
);
room = shotResult.text;
const oldHeadResult = removeOnce(
  room,
  `    const head = origin.y + dir.y * best.t > best.state.y + heightOf(best.state) - 0.25;\n`,
  "room.js 旧的 head 计算",
);
room = oldHeadResult.text;

room = room.split("\n").filter((line) => !(line.includes("HackBot") && line.includes("补采样"))).join("\n");

const botHook = `
        this.anticheat.onInput(p, p.input, now);
`;
const botHookResult = removeOnce(room, botHook, "HackBot 补采样");
room = botHookResult.text;
const botLineResult = removeOnce(
  room,
  `        this.anticheat.onInput(p, p.input, now);\n`,
  "HackBot 补采样单行",
);
room = botLineResult.text;

const httpChanged = writeWithBackup(httpPath, read(httpPath), http);
const roomChanged = writeWithBackup(roomPath, read(roomPath), room);

console.log(`[YokaiAC] 注入完成：${root}`);
console.log(`[YokaiAC] http.js：${httpChanged ? "已修改" : "无需修改"}`);
console.log(`[YokaiAC] room.js：${roomChanged ? "已修改" : "无需修改"}`);
if (httpChanged || roomChanged) console.log("[YokaiAC] 原文件已备份为 *.bak-时间戳");
