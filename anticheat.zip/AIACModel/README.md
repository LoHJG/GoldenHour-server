# AIACModel

Golden Hour 服务端的 AI 视角检测模型目录。

**当前目录不包含任何模型文件。** 需要先采数据、再训练，生成的 `model.json` 才会被服务端加载。

## 目录

```text
AIACModel/
  README.md
  train.py          # PyTorch 训练 + 导出 model.json
  requirements.txt
  data/             # 采集的 jsonl，训练前为空
  model.json        # 训练产物，当前不存在
```

## 模型结构

轻量 1D CNN，纯 Node 推理，不依赖 Python/ONNX：

```text
输入 3 × 150
  yaw 增量（度，wrap 到 -180..180）
  pitch 增量（度）
  旋转幅值 sqrt(dyaw² + dpitch²)

Conv1d(3→32, k=5, p=2) + ReLU
Conv1d(32→48, k=5, p=4, dilation=2) + ReLU
Conv1d(48→64, k=3, p=1) + ReLU
GlobalAvg + GlobalMax → 128
Linear(128→48) + ReLU
Linear(48→1) + Sigmoid
```

参数量约 2.4 万，CPU 推理开销很小。模型文件是 JSON 权重，服务端 `src/ai/model.js` 直接做前向。

## 第一步：采数据

训练样本由服务端自动写入 `AIACModel/data/rotations-<label>-<日期>.jsonl`。

### 正常玩家

```bash
AI_AC_ENABLED=1 \
AI_AC_RECORD=1 \
AI_AC_RECORD_LABEL=legit \
npm start
```

让不同玩家正常打若干局，覆盖：

- 不同灵敏度，尤其 `sens=3.0`、`adsSens=1.5`
- 鼠标、手柄、触屏/陀螺仪
- 静止、跟枪、甩枪、瞬转、反复转身
- 不同帧率/网络抖动

### 作弊样本

同一个服务端也可以单独跑一轮：

```bash
AI_AC_ENABLED=1 \
AI_AC_RECORD=1 \
AI_AC_RECORD_LABEL=cheat \
AI_AC_CHECK_BOTS=1 \
npm start
```

> 只录一个外挂不够。模型会只学会这个外挂的节奏，换一个外挂或人类高灵敏度甩枪就可能误判。

### 数据格式

每条样本是一次 150 包窗口：

```json
{
  "v": 1,
  "ts": 1770000000000,
  "player": "Hacker",
  "uid": "bot-1",
  "bot": true,
  "ai": false,
  "label": "cheat",
  "window": 150,
  "seq": {
    "dyaw": [0.0, 1.2, -0.4, "..."],
    "dpitch": [0.0, -0.3, 0.1, "..."]
  },
  "prob": null
}
```

`prob` 只在已加载模型时写入；训练脚本不使用它。

## 第二步：训练

```bash
cd AIACModel
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python train.py --data data --out model.json
```

常用参数：

```bash
python train.py \
  --data data \
  --out model.json \
  --window 150 \
  --epochs 30 \
  --batch-size 64 \
  --lr 1e-3 \
  --val-ratio 0.2 \
  --max-fpr 0.01
```

训练脚本会：

1. 读取所有 `data/*.jsonl`
2. 只保留 `label=legit/cheat` 且长度正好 150 的样本
3. 按玩家切分训练/验证，避免同一玩家同时出现在两侧
4. 只用训练集计算三通道均值/标准差
5. 训练 1D CNN，按验证集误报上限选阈值
6. 导出 `AIACModel/model.json`

数据量建议：

- 每类至少几百个窗口，最好上千
- 至少几十个不同玩家/作弊样本
- 正常样本要明显多于作弊样本，优先压误报
- 训练/验证必须按玩家切分，不能按样本随机切，否则指标虚高

## 第三步：使用

训练出 `model.json` 后：

```bash
AI_AC_ENABLED=1 npm start
```

或指定路径/阈值：

```bash
AI_AC_ENABLED=1 \
AI_AC_MODEL=AIACModel/model.json \
npm start
```

配置在 `src/config.js` 的 `ANTICHEAT.ai`：

| 配置 | 默认 | 说明 |
|---|---:|---|
| `enabled` | `false` | 是否启用 AI 推理/采集 |
| `record` | `false` | 是否写训练数据 |
| `modelPath` | `AIACModel/model.json` | 模型 JSON |
| `dataDir` | `AIACModel/data` | 数据目录 |
| `recordLabel` | `unknown` | 本轮数据标签 |
| `window` | `150` | 窗口包数，必须与模型一致 |
| `combatWindowMs` | `5000` | 开火后多久没新开火就丢弃窗口 |
| `maxGapMs` | `250` | 超过该间隔不累计转角 |
| `threshold` | `null` | `null` 用模型自带阈值 |
| `reportCooldownMs` | `5000` | 同一玩家 AI 日志间隔 |
| `reportLabel` | `Aim` | 保持现有五类显示名 |
| `checkBots` | `false` | 是否检测/采集 bot |

命中时日志：

```text
[AntiCheat] Hacker failed AI [x1] (AI p=0.923)
```

## 模型文件格式

`model.json` 由训练脚本生成，结构：

```json
{
  "format": "AIACModel/v1",
  "arch": "cnn1d",
  "window": 150,
  "channels": 3,
  "threshold": 0.82,
  "norm": { "mean": [0, 0, 30], "std": [20, 12, 35] },
  "layers": [
    {
      "type": "conv1d",
      "in": 3,
      "out": 32,
      "kernel": 5,
      "padding": 2,
      "dilation": 1,
      "weight": [],
      "bias": []
    }
  ],
  "head": {
    "in": 128,
    "hidden": 48,
    "weight1": [],
    "bias1": [],
    "weight2": [],
    "bias2": []
  }
}
```

`weight` 按 PyTorch 的 `[out, in, kernel]` 顺序扁平化；`head.weight1` 按 `[hidden, in]`，`weight2` 按 `[1, hidden]`。