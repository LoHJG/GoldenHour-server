#!/usr/bin/env python3
"""AIACModel训练脚本"""
import argparse
import glob
import json
import os
import random
from dataclasses import dataclass

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset


@dataclass
class Sample:
    player: str
    label: int
    dyaw: np.ndarray
    dpitch: np.ndarray


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="AIACModel/data", help="jsonl 数据目录")
    p.add_argument("--out", default="AIACModel/model.json", help="导出的模型文件")
    p.add_argument("--window", type=int, default=150, help="窗口包数，必须与服务端一致")
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch-size", type=int, default=64)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--val-ratio", type=float, default=0.2)
    p.add_argument("--max-fpr", type=float, default=0.01, help="选阈值时允许的验证集误报率上限")
    p.add_argument("--split-by-player", action="store_true", default=True)
    p.add_argument("--no-split-by-player", action="store_false", dest="split_by_player")
    p.add_argument("--seed", type=int, default=2026)
    return p.parse_args()


def load_samples(data_dir, window):
    files = sorted(glob.glob(os.path.join(data_dir, "*.jsonl")))
    if not files:
        raise SystemExit(f"没有找到数据文件：{data_dir}/*.jsonl")

    samples = []
    skipped = 0
    for path in files:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    skipped += 1
                    continue
                label_raw = str(item.get("label", "")).lower()
                if label_raw in ("cheat", "hack", "1", "true"):
                    label = 1
                elif label_raw in ("legit", "human", "0", "false"):
                    label = 0
                else:
                    skipped += 1
                    continue
                seq = item.get("seq") or {}
                dyaw = np.asarray(seq.get("dyaw", []), dtype=np.float32)
                dpitch = np.asarray(seq.get("dpitch", []), dtype=np.float32)
                if dyaw.size != window or dpitch.size != window:
                    skipped += 1
                    continue
                samples.append(Sample(
                    player=str(item.get("player") or item.get("uid") or "unknown"),
                    label=label,
                    dyaw=dyaw,
                    dpitch=dpitch,
                ))
    if not samples:
        raise SystemExit(f"没有可用样本，跳过 {skipped} 条")
    print(f"读取 {len(samples)} 条样本，跳过 {skipped} 条")
    print(f"legit={sum(1 for s in samples if s.label == 0)} cheat={sum(1 for s in samples if s.label == 1)}")
    return samples


def build_x(samples, window):
    x = np.zeros((len(samples), 3, window), dtype=np.float32)
    for i, s in enumerate(samples):
        x[i, 0] = s.dyaw
        x[i, 1] = s.dpitch
        x[i, 2] = np.hypot(s.dyaw, s.dpitch)
    return x


def split_samples(samples, val_ratio, by_player, seed):
    rng = random.Random(seed)
    if by_player:
        players = sorted({s.player for s in samples})
        rng.shuffle(players)
        val_players = set(players[:max(1, int(round(len(players) * val_ratio)))]) if len(players) > 1 else set()
        train = [s for s in samples if s.player not in val_players]
        val = [s for s in samples if s.player in val_players]
        if not train or not val:
            print("按玩家切分后某一侧为空，退回随机切分")
            by_player = False
    if not by_player:
        order = list(range(len(samples)))
        rng.shuffle(order)
        n_val = max(1, int(round(len(samples) * val_ratio)))
        val_idx = set(order[:n_val])
        train = [s for i, s in enumerate(samples) if i not in val_idx]
        val = [s for i, s in enumerate(samples) if i in val_idx]
    return train, val


class RotationCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv1d(3, 32, kernel_size=5, padding=2, dilation=1)
        self.conv2 = nn.Conv1d(32, 48, kernel_size=5, padding=4, dilation=2)
        self.conv3 = nn.Conv1d(48, 64, kernel_size=3, padding=1)
        self.fc1 = nn.Linear(128, 48)
        self.fc2 = nn.Linear(48, 1)

    def forward(self, x):
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = torch.relu(self.conv3(x))
        avg = x.mean(dim=2)
        peak = x.amax(dim=2)
        z = torch.cat([avg, peak], dim=1)
        z = torch.relu(self.fc1(z))
        return self.fc2(z).squeeze(1)


def choose_threshold(labels, probs, max_fpr):
    best = (0.85, -1.0, 0.0, 0.0)
    for th in np.linspace(0.05, 0.95, 91):
        pred = probs >= th
        tp = int(np.sum(pred & (labels == 1)))
        fp = int(np.sum(pred & (labels == 0)))
        tn = int(np.sum((~pred) & (labels == 0)))
        fn = int(np.sum((~pred) & (labels == 1)))
        fpr = fp / max(1, fp + tn)
        tpr = tp / max(1, tp + fn)
        precision = tp / max(1, tp + fp)
        recall = tpr
        f1 = 2 * precision * recall / max(1e-9, precision + recall)
        #优先满足误报上限，再按 F1 选
        score = f1 - max(0.0, fpr - max_fpr) * 5.0
        if score > best[1]:
            best = (float(th), score, fpr, f1)
    return best[0], {"fpr": best[2], "f1": best[3]}


def export_model(model, norm, threshold, args, train_count, val_count):
    layers = []
    for conv in (model.conv1, model.conv2, model.conv3):
        layers.append({
            "type": "conv1d",
            "in": int(conv.in_channels),
            "out": int(conv.out_channels),
            "kernel": int(conv.kernel_size[0]),
            "padding": int(conv.padding[0]),
            "dilation": int(conv.dilation[0]),
            "weight": conv.weight.detach().cpu().numpy().reshape(-1).tolist(),
            "bias": conv.bias.detach().cpu().numpy().reshape(-1).tolist(),
        })
    payload = {
        "format": "AIACModel/v1",
        "arch": "cnn1d",
        "window": int(args.window),
        "channels": 3,
        "threshold": float(threshold),
        "norm": {
            "mean": [float(v) for v in norm["mean"]],
            "std": [float(v) for v in norm["std"]],
        },
        "layers": layers,
        "head": {
            "in": 128,
            "hidden": 48,
            "weight1": model.fc1.weight.detach().cpu().numpy().reshape(-1).tolist(),
            "bias1": model.fc1.bias.detach().cpu().numpy().reshape(-1).tolist(),
            "weight2": model.fc2.weight.detach().cpu().numpy().reshape(-1).tolist(),
            "bias2": model.fc2.bias.detach().cpu().numpy().reshape(-1).tolist(),
        },
        "training": {
            "samples": int(train_count + val_count),
            "train": int(train_count),
            "val": int(val_count),
            "epochs": int(args.epochs),
        },
    }
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    print(f"模型已导出：{args.out}")


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)

    samples = load_samples(args.data, args.window)
    train_s, val_s = split_samples(samples, args.val_ratio, args.split_by_player, args.seed)
    if not train_s or not val_s:
        raise SystemExit("训练/验证集为空")

    train_x = build_x(train_s, args.window)
    val_x = build_x(val_s, args.window)
    train_y = np.asarray([s.label for s in train_s], dtype=np.float32)
    val_y = np.asarray([s.label for s in val_s], dtype=np.float32)

    #归一化参数只用训练集计算，验证集和线上都复用
    mean = train_x.mean(axis=(0, 2))
    std = train_x.std(axis=(0, 2))
    std = np.maximum(std, 1e-3)
    train_x = np.clip((train_x - mean[None, :, None]) / std[None, :, None], -6, 6)
    val_x = np.clip((val_x - mean[None, :, None]) / std[None, :, None], -6, 6)
    norm = {"mean": mean.tolist(), "std": std.tolist()}

    train_ds = TensorDataset(torch.from_numpy(train_x), torch.from_numpy(train_y))
    val_ds = TensorDataset(torch.from_numpy(val_x), torch.from_numpy(val_y))
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

    device = torch.device("cpu")
    model = RotationCNN().to(device)
    pos = max(1, int(train_y.sum()))
    neg = max(1, int(len(train_y) - pos))
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([neg / pos], dtype=torch.float32))
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=2e-3)

    print(f"train={len(train_s)} val={len(val_s)} device=cpu")
    for epoch in range(1, args.epochs + 1):
        model.train()
        total = 0.0
        for xb, yb in train_loader:
            opt.zero_grad()
            logits = model(xb)
            loss = loss_fn(logits, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
            opt.step()
            total += float(loss.item()) * len(xb)
        print(f"epoch {epoch:02d}/{args.epochs} loss={total / len(train_s):.4f}")

    model.eval()
    probs = []
    labels = []
    with torch.no_grad():
        for xb, yb in val_loader:
            probs.extend(torch.sigmoid(model(xb)).cpu().numpy().tolist())
            labels.extend(yb.cpu().numpy().tolist())
    probs = np.asarray(probs, dtype=np.float32)
    labels = np.asarray(labels, dtype=np.int32)
    threshold, metrics = choose_threshold(labels, probs, args.max_fpr)
    print(f"val threshold={threshold:.2f} fpr={metrics['fpr']:.4f} f1={metrics['f1']:.4f}")

    export_model(model, norm, threshold, args, len(train_s), len(val_s))


if __name__ == "__main__":
    main()
